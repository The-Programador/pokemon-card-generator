/* Gerar cards para redes sociais */
const generate = () => {
    let cardContainer = document.getElementsByClassName('card-container')[0];
    cardContainer.innerHTML = '';
    let inputPokemon = document.getElementsByClassName('search-pokemon')
    for(let position = 0; position < inputPokemon.length; position++) {
        cardContainer.insertAdjacentHTML('beforeend', CARD)
    }
    search()
}

const search = () => {
    let inputPokemon = document.getElementsByClassName('search-pokemon')
    for(let position = 0; position < inputPokemon.length; position++) {
        getPokemonData(inputPokemon[position].value.toLowerCase(), position)
    }
    //setTimeout(show, 98) //Não muito útil :/
}

const getPokemonData  = (_namePokemon, id) => {
    fetch(`https://pokeapi.co/api/v2/pokemon/${_namePokemon}`)
        .then(response => response.json())
        //Requisicão bem sucedida.
        .then(data => {
            //Caso tudo esteja correto.            
            constructCard(filterDataPokemon(data), id)
        })
        //Requisição mal-sucedia ou outro erro.
        .catch(err => {
            showError()
        })
}

const filterDataPokemon = _content => {
    let info = []
    //Basic informations
    let name = _content.name;
    let order = _content.id;
    let urlSpecie = _content.species.url //Outro endpoint da API
    let types = _content.types;
    console.log(_content.types)
    let weight = _content.weight / 10 //Hectograma para Kilograma
    let height = _content.height / 10 //Decimêtro para Metro
    //Stats
    let stats = []; //Vai receber as estatísticas básicas
    let statsList = _content.stats;
    for(let stat in statsList) {
        stats.push(statsList[stat].base_stat);
    }
    //Image
    let resource = _content.sprites
    let imgURL1 = resource.other.dream_world.front_default;
    let imgURL2 = resource.front_default;
    let imgURL = imgURL1 === null ? imgURL2:imgURL1;
    info.push(name, imgURL, stats, order, weight, height, urlSpecie, types);
    return info;
}


const constructCard = (_info, id) => {
    fetch(_info[6])
    .then(response =>
        response.json())
    .then(data => {
        let color = data['color']['name']
        if(color == 'white') {
            color = '#ebebeb'
        }
        cardBackground.style.backgroundColor = color
    })
    .catch(error => {
        cardBackground.style.backgroundColor = 'lightgray'
    })

    //Criar div e inserir elementos por adjascentHTML
    let cards = document.getElementsByClassName('card')
    let cardBackground = document.createElement('div')
    let cardPokemonTitle = document.createElement('p')
    let cardPokemonImage = document.createElement('div')
    let pokemonImage = document.createElement('img')
    let subCard = document.createElement('div')
    let subCardInfoBio = document.createElement('div')
    let left = document.createElement('div')
    let right = document.createElement('div')
    let type = document.createElement('p')
    let weightPokemon = document.createElement('p')
    let heightPokemon = document.createElement('p')
    let boxStats = document.createElement('div')
    let boxStatsTitle = document.createElement('p')
   
    cardBackground.className = 'card-background'
    cardPokemonTitle.className = 'card-pokemon-title';
    cardPokemonImage.className = 'card-pokemon-image';
    pokemonImage.className = 'pokemon-image';
    subCardInfoBio.className = 'sub-card-info-bio'
    type.className = 'type';
    weightPokemon.className = 'weight-pokemon';
    heightPokemon.className = 'height-pokemon';
    subCard.className = 'sub-card';
    boxStats.className = 'box-stats';
    boxStatsTitle.className = 'box-stats-title'
    //boxStatsTitle.className = 'box-stats-title'

    let statsList = ['HP', 'Attack', 'Defense', 'Special Attack', 'Special-Defence', 'Speed']

    boxStatsTitle.textContent = 'Stats';
    boxStats.appendChild(boxStatsTitle);

    //Constrói as Stats
    for(let pos in _info[2]) {
        //Define o Elementos
        let nameStat = document.createElement('span')
        let bar = document.createElement('span')
        let barMin = document.createElement('span')
        let stat = document.createElement('p');
        //Define as Classes
        nameStat.className = 'name-stat'
        bar.className =  'bar';
        barMin.className =  'bar-min';
        stat.className = 'stat';
        //Atribui os valores das stats e adiciona sub-área
        nameStat.insertAdjacentHTML("beforeend",`<span>${statsList[pos]}</span> <span class="stats-value">${_info[2][pos]}</span>`)
        barMin.style.width = `${_info[2][pos]*1.7}px`;
        bar.appendChild(barMin)
        boxStats.appendChild(stat)
        stat.appendChild(nameStat)
        stat.appendChild(bar)
    }

    type.insertAdjacentHTML('beforeend', `<span class="type-title">Type</span>`)
    //Type Pokémon
    for(let indice in _info[7]){
        type.insertAdjacentHTML('beforeend', `<span class="${_info[7][indice].type.name}">${_info[7][indice].type.name}</span>`)
    }

    weightPokemon.insertAdjacentHTML('beforeend', `<span>Weight:</span> <span>${_info[4]}kg</span>`);

    heightPokemon.insertAdjacentHTML('beforeend', `<span>Height:</span> <span>${_info[5]}m</span>`);
    
    cardPokemonTitle.textContent = `${_info[0]} #${_info[3]}`;
    pokemonImage.setAttribute('src', _info[1])
    cardPokemonImage.appendChild(pokemonImage)
    right.appendChild(type)
    left.appendChild(weightPokemon)
    left.appendChild(heightPokemon)
    subCardInfoBio.appendChild(left)
    subCardInfoBio.appendChild(right)
    subCard.appendChild(boxStats);

    cards[id].innerHTML = '';
    cards[id].appendChild(cardBackground)
    cards[id].appendChild(cardPokemonTitle)
    cards[id].append(cardPokemonImage)
    cards[id].appendChild(subCardInfoBio)
    cards[id].append(subCard)
    //cards[id].className = 'card'

    if(id === 1) {
        show()
    }
    pokemonCardCompare(_info)
}

let ocorrency = 0
let pokemonCompare = []

const pokemonCardCompare = (info) => {
    ocorrency++
    let statsTotal = 0
    info[2].forEach( (stat) => {
        statsTotal += stat
    })
    let name = info[0]
    pokemonCompare.push([name, statsTotal])
    console.log(pokemonCompare)
    if(ocorrency == 2) {
        let winner = pokemonCompare[0][1] > pokemonCompare[1][1] ? pokemonCompare[0]:pokemonCompare[1];
        let loser = pokemonCompare[0][1] < pokemonCompare[1][1] ? pokemonCompare[0]:pokemonCompare[1];
        let cardContainer = document.getElementsByClassName('card-container')[0];
        let comparisonBox = document.createElement('div')
        comparisonBox.innerHTML = ''
        comparisonBox.style.backgroundColor = 'whitesmoke'
        comparisonBox.style.color = 'var(--color1)';
        comparisonBox.style.padding = '30px'
        comparisonBox.textContent = `${pokemonCompare[0][0]} ${pokemonCompare[0][1]} | ${pokemonCompare[1][0]} ${pokemonCompare[1][1]}
        | ${winner[0]} é Superior ao ${loser[0]}`
        cardContainer.appendChild(comparisonBox)
        ocorrency = 0
        pokemonCompare = []
    }
    
}

const showError = () => {
    let cardContainer = document.getElementsByClassName('card-container')[0];
    cardContainer.innerHTML = ''
    let boxError = document.createElement('div')
    boxError.className = 'box-error'
    boxError.insertAdjacentHTML('beforeend', `<p class="msg-error">Algum Recurso Solicitado Não Existe!</p>`)
    cardContainer.appendChild(boxError)
}

const show = () => {
    let cards = document.getElementsByClassName('card')
    cards.item(0).className = 'card';
    cards.item(1).className = 'card';
}

//Card Pokémon
const CARD = `<div class="card hidden">
                <p>Pokémon!!</p>
              </div>
        `

let button = document.getElementsByClassName('button')[0]
button.addEventListener('click', generate)