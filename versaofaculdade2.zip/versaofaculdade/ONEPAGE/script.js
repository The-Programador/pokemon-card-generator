const CARD = `<div class="card hidden">
            <p>Pokémon!!</p>
         </div>
        `
cardsLen = 0
let base = 0
let limit = 9
/*
reformular o código de geração automática para buscar a partir desse end-point da POKEAPI 
https://pokeapi.co/api/v2/pokemon?limit=100000&offset=0
e ir buscar as outra informações a partir do link gerado
*/


let dataFinal = ''


fetch('https://pokeapi.co/api/v2/pokemon?limit=100000&offset=0')
.then(response => response.json())
.then(data => {
    dataFinal = data
    console.log(dataFinal)
})



//Isso aqui é ssincronismo!!
function gerar() {
    if(base < 10228) {
        if(base < 898) {
            let body = document.getElementsByClassName('box')[0]
            for(let i = 0; i < 9; i++) {
                body.insertAdjacentHTML('beforeend', CARD)
            }
            search()
        } else {
            let body = document.getElementsByClassName('box')[0]
            for(let i = 0; i < 9; i++) {
                body.insertAdjacentHTML('beforeend', CARD)
            }
            search2()
        }
    }
}

//Isso aqui é ssincronismo!!
function show() {
    let card = document.getElementsByClassName('card')
    for(let i = 0; i < card.length; i++) {
        card[i].style.display = 'flex';
    }
}

//Isso aqui é sincronismo!!
//OTIMZAR Essas duas funções
function search() {
    for(base; base < limit; base++) {
        if(base < 898) {
            cardsLen++
            getPokemonData(base+1, base)
        }
        if(base == 897) {
            base = 10000;
            limit = 10000;
            break;
        }
    }
    limit += 9
    setTimeout(show, 98) //Não muito útil :/
}

function search2() {
    for(base; base < limit; base++) {
        if(base < 10229) {
            getPokemonData(base+1, cardsLen++)
        }else {
            break;
        }
    }
    limit += 100
    setTimeout(show, 98) //Não muito útil :/
}

//Isso aqui é assincronismo!!
//OTIMIZAR ESSA FUNÇÂO
const getPokemonData = async (_namePokemon, id) => {
    fetch(`https://pokeapi.co/api/v2/pokemon/${_namePokemon}`)
    .then(response => response.json())

    //Requisicão bem sucedida.
    .then(data => {
        //SVG
        let imgURL1 = data['sprites']['other']['dream_world']['front_default']
        //PNG
        let imgURL2 = data['sprites']['front_default']
        let card = document.getElementsByClassName('card')
        card[id].id = id
        card[id].addEventListener('click', () => {
            showModal(card[id].id)
        })
        card[id].innerHTML = `
            <p>#${data['id']} ${data['name']}</p>
            <div class="box-image"><img class="image" src="${imgURL1}"></div>`;

    })

    //Requisição mal-sucedia.
    .catch(err => {
        //alert('Pokemon não encontrado!');
        console.log('0')
    })
}

const filterDataPokemon = _content => {
    let info = []
    //Basic informations
    let name = _content.name;
    let order = _content.id;
    let urlSpecie = _content.species.url //Outro endpoint da API
    let types = _content.types;
    console.log(_content.types)
    let weight = _content.weight / 10 //Hectograma para Kilograma
    let height = _content.height / 10 //Decimêtro para Metro
    //Stats
    let stats = []; //Vai receber as estatísticas básicas
    let statsList = _content.stats;
    for(let stat in statsList) {
        stats.push(statsList[stat].base_stat);
    }
    //Image
    let resource = _content.sprites
    let imgURL1 = resource.other.dream_world.front_default;
    let imgURL2 = resource.front_default;
    let imgURL = imgURL1 === null ? imgURL2:imgURL1;
    info.push(name, imgURL, stats, order, weight, height, urlSpecie, types);
    return info;
}

const showModal = (id) => {
    id = Number(id) + 1
    fetch(`https://pokeapi.co/api/v2/pokemon/${id}`)
    .then(response => response.json())
    //Requisicão bem sucedida.
    .then(data => {
        let _info = filterDataPokemon(data)
        let cardBackground = document.createElement('div')
        let cardPokemonTitle = document.createElement('p')
        let cardPokemonImage = document.createElement('div')
        let pokemonImage = document.createElement('img')
        let subCard = document.createElement('div')
        let subCardInfoBio = document.createElement('div')
        let left = document.createElement('div')
        let right = document.createElement('div')
        let type = document.createElement('p')
        let weightPokemon = document.createElement('p')
        let heightPokemon = document.createElement('p')
        let boxStats = document.createElement('div')
        let boxStatsTitle = document.createElement('p')
    
        cardBackground.className = 'card-background'
        cardPokemonTitle.className = 'card-pokemon-title';
        cardPokemonImage.className = 'card-pokemon-image';
        pokemonImage.className = 'pokemon-image';
        subCardInfoBio.className = 'sub-card-info-bio'
        type.className = 'type';
        weightPokemon.className = 'weight-pokemon';
        heightPokemon.className = 'height-pokemon';
        subCard.className = 'sub-card';
        boxStats.className = 'box-stats';
        boxStatsTitle.className = 'box-stats-title'
        //boxStatsTitle.className = 'box-stats-title'

        let statsList = ['HP', 'Attack', 'Defense', 'Special Attack', 'Special-Defence', 'Speed']

        boxStatsTitle.textContent = 'Stats';
        boxStats.appendChild(boxStatsTitle);

        //Constrói as Stats
        for(let pos in _info[2]) {
            //Define o Elementos
            let nameStat = document.createElement('span')
            let bar = document.createElement('span')
            let barMin = document.createElement('span')
            let stat = document.createElement('p');
            //Define as Classes
            nameStat.className = 'name-stat'
            bar.className =  'bar';
            barMin.className =  'bar-min';
            stat.className = 'stat';
            //Atribui os valores das stats e adiciona sub-área
            nameStat.insertAdjacentHTML("beforeend",`<span>${statsList[pos]}</span> <span class="stats-value">${_info[2][pos]}</span>`)
            barMin.style.width = `${_info[2][pos]*1.7}px`;
            bar.appendChild(barMin)
            boxStats.appendChild(stat)
            stat.appendChild(nameStat)
            stat.appendChild(bar)
        }

        type.insertAdjacentHTML('beforeend', `<span class="type-title">Type</span>`)

        for(let indice in _info[7]){
            type.insertAdjacentHTML('beforeend', `<span>${_info[7][indice].type.name}</span>`)
        }

        weightPokemon.insertAdjacentHTML('beforeend', `<span>Weight:</span> <span>${_info[4]}kg</span>`);

        heightPokemon.insertAdjacentHTML('beforeend', `<span>Height:</span> <span>${_info[5]}m</span>`);
        
        cardPokemonTitle.textContent = `${_info[0]} #${_info[3]}`;
        pokemonImage.setAttribute('src', _info[1])
        cardPokemonImage.appendChild(pokemonImage)
        right.appendChild(type)
        left.appendChild(weightPokemon)
        left.appendChild(heightPokemon)
        subCardInfoBio.appendChild(left)
        subCardInfoBio.appendChild(right)
        subCard.appendChild(boxStats);

        let button = document.createElement('button')
        let button2 = document.createElement('button')
        button.textContent = 'Fechar'
        button2.textContent = 'Fechar'
        button.className = 'button-close';
        button2.className = 'button-close'
        button.addEventListener('click', closeModal)
        button2.addEventListener('click', closeModal)
        let body = document.getElementsByTagName('body')[0];
        let modal = document.createElement('div');
        let modal2 = document.createElement('div');
        modal.appendChild(button)
        modal2.appendChild(button2)
        modal.className = 'modal';
        modal2.className = 'modal-2';

        //cards[id].innerHTML = '';
        modal.appendChild(cardBackground)
        modal.appendChild(cardPokemonTitle)
        modal.append(cardPokemonImage)
        modal.appendChild(subCardInfoBio)
        modal.append(subCard)
        body.appendChild(modal)
        body.insertAdjacentElement('beforeend', modal2)

        fetch(`https://pokeapi.co/api/v2/pokemon-species/${id}`)
        .then(response => response.json())
        .then(datalist => {
            evURL = datalist.evolution_chain.url
            fetch(evURL)
            .then(response => response.json())
            .then(evData => {
                let evolvesTo = evData.chain.evolves_to[0]
                console.log(evolvesTo)
            })
        }) 

        //SVG
        /*let imgURL = data['sprites']['other']['dream_world']['front_default']
        let button = document.createElement('button')
        let button2 = document.createElement('button')
        button.textContent = 'Fechar'
        button2.textContent = 'Fechar'
        button.className = 'button-close';
        button2.className = 'button-close'
        button.addEventListener('click', closeModal)
        button2.addEventListener('click', closeModal)
        let body = document.getElementsByTagName('body')[0];
        let modal = document.createElement('div');
        let modal2 = document.createElement('div');
        modal.appendChild(button)
        modal2.appendChild(button2)
        modal.className = 'modal';
        modal2.className = 'modal-2';
        modal.insertAdjacentElement('beforeend', button)
        modal.insertAdjacentHTML('beforeend', `<div><div class="box-img-modal"><img src=${imgURL}></div><div>`)
        body.appendChild(modal)
        body.insertAdjacentElement('beforeend', modal2)*/
        
    })

    //Requisição mal-sucedia.
    .catch(err => {
        //alert('Pokemon não encontrado!');
        console.log('0')
    })
}

const closeModal = () => {
    let modal = document.getElementsByClassName('modal')[0];
    let modal2 = document.getElementsByClassName('modal-2')[0]
    modal2.remove()
    modal.remove()
}

gerar()


let button = document.getElementById('gerar');
button.addEventListener('click', gerar);